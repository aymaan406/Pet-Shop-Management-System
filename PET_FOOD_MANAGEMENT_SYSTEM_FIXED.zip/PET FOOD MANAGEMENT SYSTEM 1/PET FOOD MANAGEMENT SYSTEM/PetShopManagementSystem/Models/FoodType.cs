namespace PetShopManagementSystem.Models
{
    public class FoodType
    {
        public int FoodTypeID { get; set; }

        public string TypeName { get; set; }
    }
}
